<?php
// Start a session for user login tracking
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link rel="stylesheet" href="styles.css"> <!-- Optional for styling -->
</head>
<body>
    <h1>Welcome to Registered Classes</h1>

    <p>Please choose an option:</p>

    <div>
        <a href="login.php">Login</a> | 
        <a href="register.php">Register</a>
    </div>
</body>
</html>
