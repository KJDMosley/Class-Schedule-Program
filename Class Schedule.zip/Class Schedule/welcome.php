<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

include('db.php');  // Include the database connection

$user_id = $_SESSION['user_id']; // Make sure to set user_id in the session on login

// Handle adding a new class schedule
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_class'])) {
    $class_name = $_POST['class_name'];
    $class_day = $_POST['class_day'];
    $class_time = $_POST['class_time'];

    $sql = "INSERT INTO schedules (user_id, class_name, class_day, class_time) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("isss", $user_id, $class_name, $class_day, $class_time);
    $stmt->execute();
}

// Handle editing a class
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_class'])) {
    $class_id = $_POST['class_id'];
    $class_name = $_POST['class_name'];
    $class_day = $_POST['class_day'];
    $class_time = $_POST['class_time'];

    $sql = "UPDATE schedules SET class_name = ?, class_day = ?, class_time = ? WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssii", $class_name, $class_day, $class_time, $class_id, $user_id);
    $stmt->execute();
}

// Handle deleting a class
if (isset($_GET['delete_class'])) {
    $class_id = $_GET['delete_class'];

    $sql = "DELETE FROM schedules WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $class_id, $user_id);
    $stmt->execute();
}

// Fetch the user's current class schedule
$sql = "SELECT * FROM schedules WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome - Class Schedules</title>
</head>
<body>
    <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>
    <p>Your Class Schedule:</p>

    <!-- Add New Class Form -->
    <h2>Add New Class</h2>
    <form method="POST" action="">
        <label for="class_name">Class Name: </label>
        <input type="text" name="class_name" required>
        <br><br>
        
        <label for="class_day">Day: </label>
        <input type="text" name="class_day" required>
        <br><br>
        
        <label for="class_time">Time: </label>
        <input type="text" name="class_time" required>
        <br><br>
        
        <button type="submit" name="add_class">Add Class</button>
    </form>

    <h2>Your Current Classes</h2>
    <?php if ($result->num_rows > 0): ?>
        <table border="1">
            <thead>
                <tr>
                    <th>Class Name</th>
                    <th>Day</th>
                    <th>Time</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['class_name']; ?></td>
                        <td><?php echo $row['class_day']; ?></td>
                        <td><?php echo $row['class_time']; ?></td>
                        <td>
                            <!-- Edit Form -->
                            <form method="POST" action="" style="display:inline;">
                                <input type="hidden" name="class_id" value="<?php echo $row['id']; ?>">
                                <input type="text" name="class_name" value="<?php echo $row['class_name']; ?>" required>
                                <input type="text" name="class_day" value="<?php echo $row['class_day']; ?>" required>
                                <input type="text" name="class_time" value="<?php echo $row['class_time']; ?>" required>
                                <button type="submit" name="edit_class">Edit</button>
                            </form>
                            <!-- Delete Link -->
                            <a href="?delete_class=<?php echo $row['id']; ?>" onclick="return confirm('Are you sure you want to delete this class?')">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>You have no classes scheduled yet.</p>
    <?php endif; ?>
</body>
</html>
